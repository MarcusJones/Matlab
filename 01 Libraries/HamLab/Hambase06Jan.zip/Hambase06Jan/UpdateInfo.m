%UPDATEINFO 05DEC to 06Jan
%
% 1) replacement of case sensitivy names
%
%
%UPDATEINFO 05Oct to 05DEC
%
% 1) replacement of hambasefun3 with hambasefun4 
% 2) replacement several xxx1204.m files with  xxx1205.m
% 3) delete buildingbase1204 (obsolete)
% 4) added building1.m; buildingm1.m; building1FF.m 
% 5) added example of eXtended HAMBase with discretization of the walls: xBuildingbaseref1205.m
%
%
%UPDATEINFO  05JULY to 05OCT
%
%
% 1) replacement of rczonef1204.m
% 2) delete of stjaninputham.m (obsolete)
% 3) adding expert functions
%       - spouw4.m
%       - Hambasefun3.m
%       - Hambasefun3meteonorm.m
%
%
% JvS 31/10/5

